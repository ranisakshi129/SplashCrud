package com.example.splashcrud.ui.getstudent.adapter;

public class StudentAdapter {
}
